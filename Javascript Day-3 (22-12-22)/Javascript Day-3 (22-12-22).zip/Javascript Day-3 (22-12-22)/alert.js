//alert('Hello'); alert('World');

//alert('Hello')
//alert('World')

/*alert(3 +
    1
    + 2);*/



/*alert("Hello");

[1, 2].forEach(alert);*/

/*let message;
message = 'Hello!';

alert(message);*/ // shows the variable content

/*let message;

message = 'Hello!';

message = 'World!'; // value changed

alert(message);*/


/*let hello = 'Hello world!';
let message;
message = hello;
alert(hello); 
alert(message); */


/*let $ = 1; 
let _ = 2; 

alert($ + _); */


/*"use strict";
const COLOR_RED = "#F00";
const COLOR_GREEN = "#0F0";
const COLOR_BLUE = "#00F";
const COLOR_ORANGE = "#FF7F00";

let color = COLOR_ORANGE;
alert(color); */


/*let name = "John";
// embed a variable
alert( `Hello, ${name}!` ); 

// embed an expression
alert( `the result is ${1 + 2}` ); */


/*let age = 100;
age = undefined;
alert(age); */


/*let user = {
    name: "John",
    age: 30,
  
    sayHi() {
      alert(this.name);
    }
  
  };
  
  user.sayHi();*/


  /*let user = {
    firstName: "Ram",
    sayHi() {
      let arrow = () => alert(this.firstName);
      arrow();
    }
  };
  
  user.sayHi();*/


  /*let str = "Hello";

alert( str.toUpperCase() );*/


let n = 1.23456;
alert( n.toFixed(2) );