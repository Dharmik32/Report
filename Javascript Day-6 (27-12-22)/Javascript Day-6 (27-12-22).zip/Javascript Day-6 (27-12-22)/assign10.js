const func = () => {

  window.open(

    "popup2.html","","left=100,top=100,width=400,height=200");

};



const end = () => {

  window.close();

};